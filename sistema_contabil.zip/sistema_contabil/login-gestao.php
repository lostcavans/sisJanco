<?php
// login-gestao.php
session_start(); // MANTER AQUI
include("config-gestao.php");

// Redirecionar se já estiver logado
if (isset($_SESSION['logado_gestao']) && $_SESSION['logado_gestao'] === true) {
    header("Location: dashboard-gestao.php");
    exit;
}

$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $empresa_id = $_POST['empresa'] ?? '';

    if (empty($username) || empty($password) || empty($empresa_id)) {
        $erro = 'Todos os campos são obrigatórios.';
    } else {
        // Buscar usuário no sistema de gestão
        $sql = "SELECT u.*, e.razao_social, e.cnpj, e.regime_tributario 
                FROM gestao_usuarios u 
                INNER JOIN gestao_user_empresa ue ON u.id = ue.user_id 
                INNER JOIN gestao_empresas e ON ue.empresa_id = e.id 
                WHERE u.username = ? AND u.ativo = 1 AND e.id = ?";
        
        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("si", $username, $empresa_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $usuario = $result->fetch_assoc();

        if ($usuario && password_verify($password, $usuario['password'])) {
            // Login bem-sucedido
            $_SESSION['logado_gestao'] = true;
            $_SESSION['usuario_id_gestao'] = $usuario['id'];
            $_SESSION['usuario_username_gestao'] = $usuario['username'];
            $_SESSION['usuario_nome_gestao'] = $usuario['nome_completo'];
            $_SESSION['usuario_nivel_gestao'] = $usuario['nivel_acesso'];
            $_SESSION['usuario_departamento_gestao'] = $usuario['departamento'];
            $_SESSION['usuario_cargo_gestao'] = $usuario['cargo'];
            $_SESSION['empresa_id_gestao'] = $empresa_id;
            $_SESSION['usuario_razao_social_gestao'] = $usuario['razao_social'];
            $_SESSION['usuario_cnpj_gestao'] = $usuario['cnpj'];
            $_SESSION['usuario_regime_tributario_gestao'] = $usuario['regime_tributario'];
            $_SESSION['ultimo_acesso_gestao'] = time();

            // Registrar log
            registrarLogGestao('LOGIN', 'Usuário ' . $usuario['username'] . ' fez login no sistema de gestão');

            header("Location: dashboard-gestao.php");
            exit;
        } else {
            $erro = 'Usuário, senha ou empresa inválidos.';
        }
    }
}

// Buscar empresas para o select
$empresas = [];
$sql = "SELECT id, razao_social, nome_fantasia FROM gestao_empresas WHERE ativo = 1 ORDER BY razao_social";
$result = $conexao->query($sql);
if ($result) {
    $empresas = $result->fetch_all(MYSQLI_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Gestão de Processos</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Estilos mantidos iguais ao anterior */
        :root {
            --primary: #4361ee;
            --primary-dark: #3a56d4;
            --secondary: #7209b7;
            --light: #f8f9fa;
            --dark: #212529;
            --gray: #6c757d;
            --gray-light: #adb5bd;
            --white: #ffffff;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --shadow-lg: 0 10px 15px rgba(0, 0, 0, 0.1);
            --border-radius: 12px;
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            color: var(--dark);
            line-height: 1.6;
        }

        .login-container {
            background: var(--white);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-lg);
            padding: 2.5rem;
            width: 100%;
            max-width: 450px;
            transition: var(--transition);
        }

        .login-container:hover {
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
        }

        .logo {
            text-align: center;
            margin-bottom: 2rem;
        }

        .logo-icon {
            font-size: 3rem;
            color: var(--primary);
            margin-bottom: 1rem;
            display: inline-block;
            padding: 15px;
            background: rgba(67, 97, 238, 0.1);
            border-radius: 50%;
        }

        h1 {
            color: var(--dark);
            font-weight: 600;
            margin-bottom: 0.5rem;
            font-size: 1.8rem;
        }

        .subtitle {
            color: var(--gray);
            font-size: 0.95rem;
        }

        .alert {
            padding: 12px 15px;
            border-radius: var(--border-radius);
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.9rem;
        }

        .alert-error {
            background-color: rgba(239, 68, 68, 0.1);
            color: #ef4444;
            border-left: 4px solid #ef4444;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            color: var(--dark);
            font-weight: 500;
            font-size: 0.9rem;
        }

        select, input {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid var(--gray-light);
            border-radius: var(--border-radius);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 1rem;
            transition: var(--transition);
        }

        select:focus, input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.2);
        }

        .btn {
            width: 100%;
            padding: 12px 15px;
            background-color: var(--primary);
            color: var(--white);
            border: none;
            border-radius: var(--border-radius);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 1rem;
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
        }

        .btn:hover {
            background-color: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: var(--shadow);
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .login-container {
            animation: fadeIn 0.6s ease-out;
        }

        @media (max-width: 480px) {
            .login-container {
                padding: 2rem 1.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="logo">
            <div class="logo-icon">
                <i class="fas fa-project-diagram"></i>
            </div>
            <h1>Acessar Sistema</h1>
            <p class="subtitle">Sistema de Gestão de Processos</p>
        </div>

        <?php if ($erro): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i>
                <?php echo htmlspecialchars($erro); ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="form-group">
                <label for="empresa">Empresa</label>
                <select id="empresa" name="empresa" required>
                    <option value="">Selecione a empresa...</option>
                    <?php foreach ($empresas as $empresa): ?>
                        <option value="<?php echo $empresa['id']; ?>">
                            <?php echo htmlspecialchars($empresa['razao_social']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="username">Usuário</label>
                <input type="text" id="username" name="username" placeholder="Seu usuário" required 
                       value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>">
            </div>

            <div class="form-group">
                <label for="password">Senha</label>
                <input type="password" id="password" name="password" placeholder="Sua senha" required>
            </div>

            <button type="submit" class="btn">
                Entrar no Sistema
            </button>
        </form>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('username').focus();
        });
    </script>
</body>
</html>